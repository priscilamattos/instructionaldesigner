Safe Home Insurance — Customer-First Conversations
Instructional Design Portfolio Concept by Priscila Mattos

Extract Interactive_Lesson.zip and open index.html to use the web lesson.
Open Branching_Scenario.pdf in a PDF reader that supports internal navigation links.
Sales_Job_Aid.pdf is a one-page printable reference.

Fictional, AI-assisted portfolio concept. Carrier and state review is needed before operational use. No client implementation or measured outcomes are claimed.
